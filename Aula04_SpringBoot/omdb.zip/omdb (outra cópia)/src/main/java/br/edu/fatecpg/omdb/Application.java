package br.edu.fatecpg.omdb;

import br.edu.fatecpg.omdb.model.Serie;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import br.edu.fatecpg.omdb.service.ConsomeApi;
import br.edu.fatecpg.omdb.service.ConverteDados;

@SpringBootApplication
public class Application implements CommandLineRunner {

	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
	}

    @Override
    public void run(String... args) throws Exception {
        System.out.println("Olá");
        String serie = "The flash";
        serie = serie.replace(" ", "+");
        String json = ConsomeApi.buscaSerie(serie);
        System.out.println(json);
        ConverteDados cd = new ConverteDados();
        Serie objectSerie = cd.obterDador(json,Serie.class);
        System.out.println(objectSerie);
    }
}
