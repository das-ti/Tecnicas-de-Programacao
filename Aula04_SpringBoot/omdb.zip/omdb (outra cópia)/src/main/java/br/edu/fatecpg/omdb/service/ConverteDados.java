package br.edu.fatecpg.omdb.service;

import br.edu.fatecpg.omdb.model.Serie;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class ConverteDados implements IConverteDados{
    private ObjectMapper mapper = new ObjectMapper();

    @Override
    public <T> T obterDador(String json, Class<T> classe) {
        try {
            return mapper.readValue(json,(Class<T>) Serie.class);
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }

    }
}
