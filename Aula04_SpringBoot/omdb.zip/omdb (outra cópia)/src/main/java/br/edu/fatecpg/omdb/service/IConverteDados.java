package br.edu.fatecpg.omdb.service;

import com.fasterxml.jackson.core.JsonProcessingException;

public interface IConverteDados {

    <T> T obterDador(String json, Class<T> classe) throws JsonProcessingException;
}
